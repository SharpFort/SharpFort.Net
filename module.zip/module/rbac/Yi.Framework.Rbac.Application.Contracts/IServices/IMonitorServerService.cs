﻿namespace Yi.Framework.Rbac.Application.Contracts.IServices
{
    public interface IMonitorServerService
    {
    }
}
