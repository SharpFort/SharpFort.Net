﻿namespace Yi.Framework.Rbac.Application.Contracts.Dtos.Account
{
    public class PhoneCaptchaImageDto
    {
        public string Phone { get; set; }
        
        public string Uuid { get; set; }

        public string Code { get; set; }
    }
}
