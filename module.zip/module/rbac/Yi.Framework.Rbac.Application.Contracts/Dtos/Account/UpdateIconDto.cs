﻿namespace Yi.Framework.Rbac.Application.Contracts.Dtos.Account
{
    public class UpdateIconDto
    {
        public string? Icon { get; set; }
        public Guid? UserId { get; set; }
    }
}
