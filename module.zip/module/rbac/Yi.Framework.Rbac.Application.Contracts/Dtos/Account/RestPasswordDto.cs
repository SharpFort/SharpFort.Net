﻿namespace Yi.Framework.Rbac.Application.Contracts.Dtos.Account
{
    public class RestPasswordDto
    {
        public string Password { get; set; } = string.Empty;
    }
}
