﻿namespace Yi.Framework.Rbac.Application.Contracts.Dtos.MonitorCache
{
    public class MonitorCacheNameGetListOutputDto
    {
        public string CacheName { get; set; }
        public string? Remark { get; set; }
    }
}
