﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Rbac.Domain.Shared.Enums
{
    public enum MenuType
    {
        Catalogue = 0,  //目录
        Menu = 1,  //菜单
        Component = 2//组件
    }
}
