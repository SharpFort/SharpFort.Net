﻿namespace Yi.Framework.Rbac.Domain.Shared.Enums;

public enum MenuSource
{
    Ruoyi=0,
    Pure=1
}