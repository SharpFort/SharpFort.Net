using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Rbac.Domain.Shared.Consts
{
    /// <summary>
    /// 常量定义
    /// </summary>

    public class MenuConst
    {
        public const string Exist = "该菜单已经存在";
    }
}
