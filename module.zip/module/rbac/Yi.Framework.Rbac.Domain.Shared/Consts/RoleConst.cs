using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Rbac.Domain.Shared.Consts
{
    /// <summary>
    /// 常量定义
    /// </summary>

    public class RoleConst
    {
        public const string Exist = "该角色已经存在";
    }
}
