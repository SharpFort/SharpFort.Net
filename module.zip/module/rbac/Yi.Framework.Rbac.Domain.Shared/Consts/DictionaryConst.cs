﻿namespace Yi.Framework.Rbac.Domain.Shared.Consts;

public class DictionaryConst
{
    public const string Exist = "该字典已经存在";
}