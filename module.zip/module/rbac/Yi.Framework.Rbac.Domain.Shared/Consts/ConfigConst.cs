﻿namespace Yi.Framework.Rbac.Domain.Shared.Consts;

public class ConfigConst
{
    public const string Exist = "该配置已经存在";
}