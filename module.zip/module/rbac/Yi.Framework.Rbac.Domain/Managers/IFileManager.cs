﻿namespace Yi.Framework.Rbac.Domain.Managers;

public interface IFileManager
{
    
}