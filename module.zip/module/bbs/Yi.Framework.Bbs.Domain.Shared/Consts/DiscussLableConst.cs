﻿namespace Yi.Framework.Bbs.Domain.Shared.Consts;

public class DiscussLableConst
{
    public const string DiscussLableCacheKey="DiscussLable:All";
}