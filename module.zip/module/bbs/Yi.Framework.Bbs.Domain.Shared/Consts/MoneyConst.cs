﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Bbs.Domain.Shared.Consts
{
    public class MoneyConst
    {
        public const string Money_Low_Zero = "钱钱不足";
    }
}
