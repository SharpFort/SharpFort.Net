using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Bbs.Domain.Shared.Consts
{
    /// <summary>
    /// 常量定义
    /// </summary>

    public class PlateConst
    {
        public const string No_Exist = "传入的板块id不存在";
    }
}
