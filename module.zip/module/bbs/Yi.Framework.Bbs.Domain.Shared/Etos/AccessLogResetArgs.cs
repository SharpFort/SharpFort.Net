﻿namespace Yi.Framework.Bbs.Domain.Shared.Etos;

public class AccessLogResetArgs
{
    
}