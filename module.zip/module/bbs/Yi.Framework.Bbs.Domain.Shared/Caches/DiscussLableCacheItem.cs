﻿namespace Yi.Framework.Bbs.Domain.Shared.Caches;

public class DiscussLableCacheItem
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public string? Color { get; set; }
    public string? BackgroundColor { get; set; }
}