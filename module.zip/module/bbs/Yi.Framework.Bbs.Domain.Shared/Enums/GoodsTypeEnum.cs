﻿namespace Yi.Framework.Bbs.Domain.Shared.Enums;

public enum GoodsTypeEnum
{
    /// <summary>
    /// 申请类型
    /// </summary>
    Apply
}