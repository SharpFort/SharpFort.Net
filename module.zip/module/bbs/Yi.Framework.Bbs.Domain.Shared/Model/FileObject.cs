﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.Bbs.Domain.Shared.Model
{
    public class FileObject
    {
        public string Content { get; set; }
        public string FileName { get; set; }
    }
}
