using Volo.Abp.Application.Services;

namespace Yi.Framework.Bbs.Application.Contracts.IServices
{
    /// <summary>
    /// Setting应用抽象
    /// </summary>
    public interface ISettingService : IApplicationService
    {
    }
}
