﻿namespace Yi.Framework.Bbs.Application.Contracts.Dtos.Shop;

public class BuyShopInputDto
{
    public Guid GoodsId { get; set; }
    public string ContactInformation { get; set; }
}