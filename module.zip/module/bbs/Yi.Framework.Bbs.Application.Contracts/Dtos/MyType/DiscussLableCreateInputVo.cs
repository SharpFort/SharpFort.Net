namespace Yi.Framework.Bbs.Application.Contracts.Dtos.MyType
{
    /// <summary>
    /// Label输入创建对象
    /// </summary>
    public class DiscussLableCreateInputVo
    {
        public string Name { get; set; }
        public string? Color { get; set; }
        public string? BackgroundColor { get; set; }
    }
}
