﻿namespace Yi.Framework.Bbs.Application.Contracts.Dtos.Analyse;

public class MoneyTopUserDto:BaseAnalyseTopUserDto
{
    public decimal Money { get; set; }

}