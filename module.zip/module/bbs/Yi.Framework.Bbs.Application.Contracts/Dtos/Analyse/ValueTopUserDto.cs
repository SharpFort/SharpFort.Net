﻿namespace Yi.Framework.Bbs.Application.Contracts.Dtos.Analyse;

public class ValueTopUserDto:BaseAnalyseTopUserDto
{
    public decimal Value { get; set; }
}