﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Yi.Framework.Ddd.Application.Contracts;

namespace Yi.Framework.Bbs.Application.Contracts.Dtos.Notice
{
    public class BbsNoticeGetListInputVo:PagedAllResultRequestDto
    {
    }
}
