﻿namespace Yi.Framework.Bbs.Domain.Entities.Shop.ValueObjects;

public class ShippingAddress
{
    
}