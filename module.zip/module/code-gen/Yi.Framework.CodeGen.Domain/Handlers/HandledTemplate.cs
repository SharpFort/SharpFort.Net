﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yi.Framework.CodeGen.Domain.Handlers
{
    public class HandledTemplate
    {
        public string TemplateStr { get; set; }

        public string BuildPath { get; set; }
    }
}
