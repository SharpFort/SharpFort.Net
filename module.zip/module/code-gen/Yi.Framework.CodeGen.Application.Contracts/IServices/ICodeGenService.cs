﻿using Volo.Abp.Application.Services;

namespace Yi.Framework.CodeGen.Application.Contracts.IServices
{
    public interface ICodeGenService : IApplicationService
    {
    }
}
