﻿using Volo.Abp.Application.Dtos;

namespace Yi.Framework.CodeGen.Application.Contracts.Dtos.Table
{
    public class TableGetListInput : PagedAndSortedResultRequestDto
    {
    }
}
