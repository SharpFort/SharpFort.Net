﻿using Yi.Framework.SqlSugarCore;

namespace Yi.Framework.CodeGen.SqlSugarCore
{
    [DependsOn(typeof(YiFrameworkSqlSugarCoreModule))]
    public class YiFrameworkCodeGenSqlSugarCoreModule:AbpModule
    {

    }
}
